TODO: add example docs structure
